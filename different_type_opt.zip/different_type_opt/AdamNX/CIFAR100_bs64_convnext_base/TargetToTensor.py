#! -*- coding:utf-8 -*-

'''
@Author:        ZM
@Date and Time: 2021/6/22 6:21
@File:          TargetToTensor.py
'''

import torch

class TargetToTensor:
    def __call__(self, target):
        return torch.as_tensor(target)