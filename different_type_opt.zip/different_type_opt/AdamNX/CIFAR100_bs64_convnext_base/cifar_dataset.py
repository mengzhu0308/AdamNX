'''
@Author:        ZM
@Date and Time: 2020/7/26 14:37
@File:          cifar_dataset.py
'''

import pickle
import numpy as np
from pathlib import Path

def get_cifar10(root_dir='/media/zm/zm1/datasets/cifar-10-batches-py'):
    def unpickle(file):
        with open(file, mode='rb') as f:
            dict = pickle.load(f, encoding='bytes')

        X = dict[b'data'].reshape(-1, 3, 32, 32).transpose(0, 2, 3, 1)
        Y = np.array(dict[b'labels'])

        return X, Y

    root_path = Path(root_dir)
    X_train = list()
    Y_train = list()

    for i in range(5):
        file_path = root_path / 'data_batch_{}'.format(i + 1)
        x, y = unpickle(file_path.as_posix())
        X_train.append(x)
        Y_train.append(y)

    X_train = np.concatenate(X_train)
    Y_train = np.concatenate(Y_train)
    X_val, Y_val = unpickle((root_path / 'test_batch').as_posix())

    return (X_train, Y_train), (X_val, Y_val)

def get_cifar100(root_dir='/media/zm/zm1/datasets/cifar-100-python'):
    def unpickle(file):
        with open(file, mode='rb') as f:
            dict = pickle.load(f, encoding='bytes')

        X = dict[b'data'].reshape(-1, 3, 32, 32).transpose(0, 2, 3, 1)
        Y = np.array(dict[b'fine_labels'])

        return X, Y

    root_path = Path(root_dir)

    X_train, Y_train = unpickle((root_path/'train').as_posix())
    X_val, Y_val = unpickle((root_path/'test').as_posix())

    return (X_train, Y_train), (X_val, Y_val)