'''
@Author:        ZM
@Date and Time: 2020/6/11 7:19
@File:          separate_params.py
'''

from torch import nn

def separate_params_v1(model):
    conv_wts = list()
    linear_wts = list()
    ignored_params = list()

    for m in model.modules():
        if isinstance(m, nn.Conv2d):
            wt = list(m.parameters())[0]
            conv_wts.append(wt)
            ignored_params.append(id(wt))
        elif isinstance(m, nn.Linear):
            wt = list(m.parameters())[0]
            linear_wts.append(wt)
            ignored_params.append(id(wt))

    base_params = list(filter(lambda p: id(p) not in ignored_params, model.parameters()))

    return conv_wts, linear_wts, base_params

def separate_params_v2(model):
    decay_wts = list()
    ignored_params = list()

    for m in model.modules():
        if isinstance(m, (nn.Conv2d, nn.Linear)):
            wt = list(m.parameters())[0]
            decay_wts.append(wt)
            ignored_params.append(id(wt))

    base_params = list(filter(lambda p: id(p) not in ignored_params, model.parameters()))

    return decay_wts, base_params