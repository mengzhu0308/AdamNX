#! -*- coding:utf-8 -*-

'''
@Author:        ZM
@Date and Time: 2022/11/7 8:43
@File:          Scale.py
'''

import torch
from torch import nn

class Scale(nn.Module):
    def __init__(self, channels, channel_dim=1, scale_init=1., device=None, dtype=None):
        factory_kwargs = {'device': device, 'dtype': dtype}
        super(Scale, self).__init__()
        self.channels = channels
        self.channel_dim = channel_dim
        self.scale_init = scale_init
        self.scale = nn.Parameter(torch.empty(self.channels, **factory_kwargs))
        self.reset_parameters()

    def reset_parameters(self):
        nn.init.constant_(self.scale, self.scale_init)

    def forward(self, x):
        input_size = x.size()
        broadcast_shape = [1] * len(input_size)
        broadcast_shape[self.channel_dim] = self.channels
        out = x * self.scale.view(broadcast_shape)
        return out

    def extra_repr(self):
        return f"channels={self.channels}, channel_dim={self.channel_dim}, scale_init={self.scale_init}"