#! -*- coding:utf-8 -*-

'''
@Author:        ZM
@Date and Time: 2021/4/14 2:08
@File:          RandomHorizontalFlip.py
'''

import random

class RandomHorizontalFlip:
    def __init__(self, p=0.5):
        self.p = p

    def __call__(self, image):
        if random.random() < self.p:
            return image

        return image[:, ::-1, ...].copy()