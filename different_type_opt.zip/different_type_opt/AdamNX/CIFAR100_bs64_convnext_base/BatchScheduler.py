#! -*- coding:utf-8 -*-

'''
@Author:        ZM
@Date and Time: 2025/8/15 10:43
@File:          BatchScheduler.py
'''

from torch.optim.lr_scheduler import LRScheduler

class BatchScheduler(LRScheduler):
    """batch级别学习率调度器"""

    def __init__(self, optimizer, lr_lambda, last_epoch=-1):
        self.lr_lambda = lr_lambda
        super().__init__(optimizer, last_epoch)

    def get_lr(self):
        step = self.last_epoch
        return [self.lr_lambda(step)] * len(self.base_lrs)

    def step(self, epoch=None):
        # 更新计数器
        if epoch is None:
            self.last_epoch += 1
        else:
            self.last_epoch = epoch

        # 计算并应用新学习率
        values = self.get_lr()
        self._update_lr(values)

    def _update_lr(self, lrs):
        for param_group, lr in zip(self.optimizer.param_groups, lrs):
            param_group['lr'] = lr
        self._last_lr = lrs