#! -*- coding:utf-8 -*-

'''
@Author:        ZM
@Date and Time: 2025/8/15 10:48
@File:          lr_lambda.py
'''

from typing import Tuple

class MyLRLambda:
    def __init__(self, lr: float, t1: int, r_min: float = 0.001) -> None:
        self.lr = lr
        self.t1 = t1
        self.r_min = r_min

    def __call__(self, batch_idx: int) -> float:
        if batch_idx > self.t1:
            r_t = self.r_min
        else:
            r_t = 1 + (self.r_min - 1) / self.t1 * batch_idx

        return self.lr * r_t


class MyLRLambdaWithWarmup:
    def __init__(self, lr: float, ts: Tuple[int, int], r_min: float = 0.001, eps: float | None = None) -> None:
        self.lr = lr
        self.ts = ts
        self.r_min = r_min
        self.eps = eps or r_min

    def __call__(self, batch_idx: int) -> float:
        t1, t2 = self.ts
        if batch_idx <= t1:
            r_t = self.eps + (1 - self.eps) / t1 * batch_idx
        elif batch_idx <= t2:
            r_t = 1 + (self.r_min - 1) / (t2 - t1) * (batch_idx - t1)
        else:
            r_t = self.r_min

        return self.lr * r_t

class MyLRLambdaWithAnnealing:
    def __init__(self, lr: float, ts: Tuple[int, int, int], r_min: float = 0.001) -> None:
        self.lr = lr
        self.ts = ts
        self.r_min = r_min

    def __call__(self, batch_idx: int) -> float:
        t1, t2, t3 = self.ts
        step = batch_idx % t3
        if step <= t1:
            r_t = 1 + (self.r_min - 1) / t1 * step
        elif t1 < step <= t2:
            r_t = self.r_min
        else:
            r_t = self.r_min + (1 - self.r_min) / (t3 - t2) * (step - t2)

        return self.lr * r_t


class MyLRLambdaWithWarmupAndAnnealing:
    def __init__(self, lr: float, ts: Tuple[int, int, int, int], r_min: float = 0.001, eps: float | None = None) -> None:
        self.lr = lr
        self.ts = ts
        self.r_min = r_min
        self.eps = eps or r_min

    def __call__(self, batch_idx: int) -> float:
        t1, t2, t3, t4 = self.ts

        if batch_idx <= t1:
            r_t = self.eps + (1 - self.eps) / t1 * batch_idx
            return self.lr * r_t

        T = t4 - t1
        delta = (batch_idx - t1) % T  # Modulo operation
        A = t2 - t1
        B = t3 - t2
        C = t4 - t3

        if delta <= A:
            r_t = 1 + (self.r_min - 1) / A * delta
        elif delta <= A + B:
            r_t = self.r_min
        else:  # delta < T
            r_t = self.r_min + (1 - self.r_min) / C * (delta - A - B)

        return self.lr * r_t

if __name__ == '__main__':
    lr_lambda = MyLRLambda(0.1, 100)
    init_lr = lr_lambda(0)
    print(init_lr)