'''
@Author:        zm
@Date and Time: 2019/8/8 18:20
@File:          trainhistory2X.py
'''

import matplotlib.pyplot as plt
import pandas as pd
import numpy as np

def trainhistory2png(hist, saved_dir='.', model_name='', dataset_name=''):
    loss = np.array(hist['loss'], dtype=np.float32)

    # Plot training loss values
    fig = plt.figure()
    ax = fig.add_subplot(1, 1, 1)
    ax.plot(loss)
    ax.legend()
    ax.grid(True)
    ax.set(ylabel='loss', xlabel='iteration')
    fig.savefig(f'{saved_dir}/{model_name}_{dataset_name}_train_loss.pdf')

def trainhistory2excel(hist, saved_dir='.', model_name='', dataset_name=''):
    loss = np.array(hist['loss'], dtype=np.float32)

    df = pd.DataFrame({"loss": loss})

    df.to_excel(f'{saved_dir}/{model_name}_{dataset_name}_train_hist.xlsx', sheet_name='History', index=False)

def trainhistory2txt(hist, saved_dir='.', model_name='', dataset_name=''):
    loss = np.array(hist['loss'], dtype=np.float32)

    lines = []
    line = 'loss\n'
    lines.append(line)
    for i, l in enumerate(loss):
        line = f'{l:.5f}\n'
        lines.append(line)

    lines[-1] = lines[-1].strip()
    with open(f'{saved_dir}/{model_name}_{dataset_name}_train_hist.txt', 'w', encoding='utf-8') as f:
        f.writelines(lines)