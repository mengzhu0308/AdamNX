#! -*- coding:utf-8 -*-

'''
@Author:        ZM
@Date and Time: 2023/6/6 9:51
@File:          ConvertImageDtype.py
'''

import numpy as np

class ConvertImageDtype:
    def __call__(self, image):
        '''
        :param image: ∈ [0, 255]
        :return: ∈ [0, 1]
        '''
        image = image.astype(np.float32)
        image = image / 255.

        return image