#! -*- coding:utf-8 -*-

'''
@Author:        ZM
@Date and Time: 2023/1/21 16:35
@File:          Permute.py
'''

from typing import List
import torch
from torch import Tensor

class Permute(torch.nn.Module):
    """This module returns a view of the tensor input with its dimensions permuted.

    Args:
        dims (List[int]): The desired ordering of dimensions
    """

    def __init__(self, dims: List[int]):
        super().__init__()
        self.dims = dims

    def forward(self, x: Tensor) -> Tensor:
        return torch.permute(x, self.dims)