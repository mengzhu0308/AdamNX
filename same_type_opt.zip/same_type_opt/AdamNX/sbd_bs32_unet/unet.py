#! -*- coding:utf-8 -*-

'''
@Author:        ZM
@Date and Time: 2023/12/23 9:53
@File:          unet.py
'''

from functools import partial
from typing import List, Tuple, Callable
import math
from torch import Tensor
import torch
from torch import nn
from torch.nn import functional as F
from unet_utils import ConvBlock, UpConvBlock


class Unet(nn.Module):
    '''引自论文U-Net：Convolutional Networks for Biomedical Image Segmentation
    '''

    __N = 5

    def __init__(self, num_classes: int = 20,
                 basic_units: int = 64,
                 units: Tuple[int, ...] | List[int] | None = None,
                 norm_layer: Callable[..., nn.Module] | None = None,
                 activation_layer: Callable[..., nn.Module] | None = None) -> None:
        units = units or [basic_units * 2 ** i for i in range(self.__N)]
        assert len(units) == self.__N
        if norm_layer is None:
            norm_layer = partial(nn.BatchNorm2d, momentum=0.01)
        if activation_layer is None:
            activation_layer = partial(nn.ReLU, inplace=True)

        super().__init__()
        self.i_conv = ConvBlock(3, units[0], norm_layer=norm_layer, activation_layer=activation_layer)

        self.down_convs = nn.ModuleList([
            ConvBlock(units[i], units[i + 1], norm_layer=norm_layer, activation_layer=activation_layer)
            for i in range(self.__N - 1)
        ])

        self.ups = nn.ModuleList([
            UpConvBlock(units[i + 1], units[i], norm_layer=norm_layer, activation_layer=activation_layer)
            for i in range(self.__N - 2, -1, -1)
        ])

        self.up_convs = nn.ModuleList([
            ConvBlock(units[i] * 2, units[i], norm_layer=norm_layer, activation_layer=activation_layer)
            for i in range(self.__N - 2, -1, -1)
        ])

        self.o_conv = nn.Conv2d(units[0], num_classes, 1)

        self._init_weights()

    def _init_weights(self) -> None:
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                fan_out = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
                nn.init.normal_(m.weight, mean=0.0, std=math.sqrt(2.0 / fan_out))
                if m.bias is not None:
                    nn.init.zeros_(m.bias)
            elif isinstance(m, nn.BatchNorm2d):
                nn.init.ones_(m.weight)
                nn.init.zeros_(m.bias)

    def forward(self, inputs: Tensor) -> Tensor:
        x = self.i_conv(inputs)
        es = [x]
        for i in range(self.__N - 1):
            e = F.max_pool2d(es[i], 3, stride=2, padding=1)
            es.append(self.down_convs[i](e))

        '''实现方式1
        es = es[::-1]
        ds = [es[0]]
        for i in range(self.__N - 1):
            d = self.ups[i](ds[i])
            e = es[i + 1]
            if d.shape[2:] != e.shape[2:]:
                d = F.interpolate(d, size=e.shape[2:], mode='bilinear', align_corners=True)
            d = torch.cat((e, d), 1)
            d = self.up_convs[i](d)
            ds.append(d)
        es = es[::-1]
        
        o = self.o_conv(ds[-1])
        '''

        '''实现方式2
        '''
        d = es.pop()
        for i in range(self.__N - 1):
            d = self.ups[i](d)
            # 确保尺寸匹配，如果不匹配则进行调整
            e = es.pop()
            if d.shape[2:] != e.shape[2:]:
                d = F.interpolate(d, size=e.shape[2:], mode='bilinear', align_corners=True)
            d = torch.cat((e, d), 1)
            d = self.up_convs[i](d)

        o = self.o_conv(d)
        return o