#! -*- coding:utf-8 -*-

'''
@Author:        ZM
@Date and Time: 2025/10/30 10:13
@File:          sbd_seg_losses.py
'''


import torch
from torch import nn


class FocalLoss(nn.Module):
    def __init__(self, alpha: float = 1, gamma: float = 2, ignore_index: int = 255) -> None:
        super().__init__()
        self.alpha = alpha
        self.gamma = gamma
        self.ignore_index = ignore_index

    def forward(self, inputs: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
        ce_loss = nn.functional.cross_entropy(
            inputs, target,
            reduction='none',
            ignore_index=self.ignore_index
        )

        pt = torch.exp(-ce_loss)
        focal_loss = self.alpha * (1 - pt) ** self.gamma * ce_loss

        return focal_loss.mean()


class DiceLoss(nn.Module):
    def __init__(self, smooth: float = 1e-6, ignore_index: int = 255) -> None:
        super().__init__()
        self.smooth = smooth
        self.ignore_index = ignore_index

    def forward(self, inputs: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
        # 创建掩码，排除ignore_index
        mask = target != self.ignore_index
        masked_target = target[mask]

        if masked_target.numel() == 0:  # 没有有效像素
            return torch.tensor(0.0, device=inputs.device)

        # 获取有效像素的预测
        n, c, h, w = inputs.shape
        inputs_flat = inputs.permute(0, 2, 3, 1).contiguous().view(-1, c)  # [n*h*w, c]
        inputs_flat = inputs_flat[mask.view(-1)]  # 只保留有效像素

        # softmax和one-hot编码
        probs = nn.functional.softmax(inputs_flat, dim=1)
        target_one_hot = nn.functional.one_hot(masked_target, num_classes=c).float()

        # 计算Dice
        intersection = torch.sum(probs * target_one_hot, dim=0)
        union = torch.sum(probs, dim=0) + torch.sum(target_one_hot, dim=0)

        dice = (2. * intersection + self.smooth) / (union + self.smooth)
        dice_loss = 1 - dice.mean()

        return dice_loss


def criterion(inputs: torch.Tensor, target: torch.Tensor, ignore_index: int = 255) -> torch.Tensor:
    loss = nn.functional.cross_entropy(inputs, target, ignore_index=ignore_index)
    return loss


def focal_criterion(inputs: torch.Tensor, target: torch.Tensor, ignore_index: int = 255) -> torch.Tensor:
    focal_loss_fun = FocalLoss(alpha=1, gamma=2, ignore_index=ignore_index)
    return focal_loss_fun(inputs, target)


def dice_criterion(inputs: torch.Tensor, target: torch.Tensor, ignore_index: int = 255) -> torch.Tensor:
    dice_loss_fun = DiceLoss(smooth=1e-6, ignore_index=ignore_index)
    return dice_loss_fun(inputs, target)

def ce_dice_criterion(inputs: torch.Tensor, target: torch.Tensor, ignore_index: int = 255) -> torch.Tensor:
    dice_loss_fun = DiceLoss(smooth=1e-6, ignore_index=ignore_index)

    ce_loss = nn.functional.cross_entropy(inputs, target, ignore_index=ignore_index)
    dice_loss = dice_loss_fun(inputs, target)

    return (ce_loss + dice_loss) * 0.5
