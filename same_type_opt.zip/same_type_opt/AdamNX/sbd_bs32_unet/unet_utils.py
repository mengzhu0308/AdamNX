#! -*- coding:utf-8 -*-

'''
@Author:        ZM
@Date and Time: 2023/12/23 9:46
@File:          unet_utils.py
'''

from typing import Callable, Tuple
from functools import partial
from torch import Tensor
from torch import nn


class ConvBlock(nn.Sequential):
    def __init__(self, in_units: int,
                 out_units: int,
                 norm_layer: Callable[..., nn.Module] | None = None,
                 activation_layer: Callable[..., nn.Module] | None = None) -> None:
        if norm_layer is None:
            norm_layer = partial(nn.BatchNorm2d, momentum=0.01)
        if activation_layer is None:
            activation_layer = partial(nn.ReLU, inplace=True)
        layers = [
            nn.Conv2d(in_units, out_units, 3, padding=1, bias=False),
            norm_layer(out_units),
            activation_layer(),
            nn.Conv2d(out_units, out_units, 3, padding=1, bias=False),
            norm_layer(out_units),
            activation_layer()
        ]
        super().__init__(*layers)


class UpConvBlock(nn.Sequential):
    def __init__(self, in_units: int,
                 out_units: int,
                 norm_layer: Callable[..., nn.Module] | None = None,
                 activation_layer: Callable[..., nn.Module] | None = None) -> None:
        if norm_layer is None:
            norm_layer = partial(nn.BatchNorm2d, momentum=0.01)
        if activation_layer is None:
            activation_layer = partial(nn.ReLU, inplace=True)
        layers = [
            nn.Conv2d(in_units, out_units, 3, padding=1, bias=False),
            nn.Upsample(scale_factor=2, mode='bilinear', align_corners=True),
            norm_layer(out_units),
            activation_layer()
        ]
        super().__init__(*layers)


class RecurrentBlock(nn.Module):
    """循环卷积块"""

    def __init__(self,
                 channels: int,
                 times: int = 2,
                 norm_layer: Callable[..., nn.Module] | None = None,
                 activation_layer: Callable[..., nn.Module] | None = None) -> None:

        norm_layer = norm_layer or partial(nn.BatchNorm2d, momentum=0.01)
        activation_layer = activation_layer or partial(nn.ReLU, inplace=True)

        super().__init__()
        self.times = times

        # 共享的卷积层
        self.conv = nn.Sequential(
            nn.Conv2d(channels, channels, 3, padding=1, bias=False),
            norm_layer(channels),
            activation_layer()
        )

    def forward(self, inputs: Tensor) -> Tensor:
        x = inputs
        for i in range(self.times):
            if i == 0:
                x = self.conv(x)
            else:
                x = self.conv(x + inputs)  # 残差连接
        return x


class RRCNNBlock(nn.Module):
    def __init__(self, in_units: int,
                 out_units: int,
                 times: int = 2,
                 norm_layer: Callable[..., nn.Module] | None = None,
                 activation_layer: Callable[..., nn.Module] | None = None) -> None:
        if norm_layer is None:
            norm_layer = partial(nn.BatchNorm2d, momentum=0.01)
        if activation_layer is None:
            activation_layer = partial(nn.ReLU, inplace=True)
        super().__init__()
        self.i_conv = nn.Conv2d(in_units, out_units, 1)
        self.recurrent_block1 = RecurrentBlock(out_units, times=times, norm_layer=norm_layer, activation_layer=activation_layer)
        self.recurrent_block2 = RecurrentBlock(out_units, times=times, norm_layer=norm_layer, activation_layer=activation_layer)

    def forward(self, inputs: Tensor) -> Tensor:
        x = self.i_conv(inputs)
        x = self.recurrent_block1(x)
        x = self.recurrent_block2(x)
        return x


class Attention(nn.Module):
    def __init__(self, l_units: int,
                 g_units: int,
                 hidden_units: int,
                 norm_layer: Callable[..., nn.Module] | None = None,
                 activation_layer: Callable[..., nn.Module] | None = None) -> None:
        if norm_layer is None:
            norm_layer = partial(nn.BatchNorm2d, momentum=0.01)
        if activation_layer is None:
            activation_layer = partial(nn.ReLU, inplace=True)
        super().__init__()
        self.W_x = nn.Sequential(
            nn.Conv2d(l_units, hidden_units, 1, bias=False),
            norm_layer(hidden_units)
        )
        self.W_g = nn.Sequential(
            nn.Conv2d(g_units, hidden_units, 1, bias=False),
            norm_layer(hidden_units)
        )
        self.psi = nn.Sequential(
            nn.Conv2d(hidden_units, 1, 1, bias=False),
            norm_layer(1),
            nn.Sigmoid()
        )
        self.activation = activation_layer()

    def forward(self, inputs: Tuple[Tensor, Tensor]) -> Tensor:
        x, g = inputs
        x1 = self.W_x(x)
        g1 = self.W_g(g)
        psi = self.activation(x1 + g1)
        psi = self.psi(psi)
        out = x * psi
        return out